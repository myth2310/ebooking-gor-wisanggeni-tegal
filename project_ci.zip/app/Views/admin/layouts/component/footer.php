<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted"> &copy; <?= date('Y') ?> | eBooking GOR Wisanggeni Tegal x Program Studi D3 Teknik Komputer - Poltek Harber.</div>
        </div>
    </div>
</footer>